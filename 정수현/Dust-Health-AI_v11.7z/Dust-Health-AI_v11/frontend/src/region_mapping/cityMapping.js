const cityMapping = {
    daegu: "대구",
    chungnam: "충남",
    incheon: "인천",
    daejeon: "대전",
    gyeongbuk: "경북",
    sejong: "세종",
    gwangju: "광주",
    jeonbuk: "전북",
    gangwon: "강원",
    ulsan: "울산",
    jeonnam: "전남",
    seoul: "서울",
    busan: "부산",
    jeju: "제주",
    chungbuk: "충북",
    gyeongnam: "경남",
    gyeonggi: "경기"
  };
  
  export default cityMapping;